#include <stdio.h>
 int main()
{ 
int num; 
printf("enter number: "); 
scanf("%d",&num); 
int reverse=0,remainder; 
while(num!=0) 
{ 
remainder = num%10; 
reverse = reverse*10 + remainder; 
num=num/10; 
} 
printf("reversed number: %d",reverse);
} 
