#include <stdio.h> 
int main() 
{ 
int n, first = 0, second = 1, temp, i; 
printf("Enter number of terms: "); 
scanf("%d", &n); 
printf("Fibonacci Series: "); 
for(i = 0; i < n; i++) { 
printf("%d ", first); 
temp = first + second; 
first = second; 
second = temp; 
} 
}
