#include <stdio.h> 
int main() 
{     
int arr[100],n,pos=0,value,i;      
printf("Enter number of elements: ");     
scanf("%d", &n);      
printf("Array elements:\n");     
for(i = 0; i < n; i++) {         
scanf("%d", &arr[i]);     
}          
int pos1=pos;          
printf("\nUse of INSERT operation.\n");     
//it adds a new element at a given position in the array.          
printf("Enter position to insert: ");     
scanf("%d", &pos1);      
printf("Enter value to be inserted: ");     
scanf("%d", &value);      
for(i = n; i >= pos1; i--) {         
arr[i] = arr[i - 1];     
}      
arr[pos1 - 1] = value;    
 n++;          
printf("array after insertion:\n");     
for(i = 0; i <n; i++) {         
printf("%d ",arr[i]);    
} 
	printf("\n\nUse of UPDATE operation.\n");     
//it changes the value at a specific position in an array.          

int pos2=pos;          
printf("Enter position to update: ");     
scanf("%d", &pos2);      
printf("Enter new value: ");     
scanf("%d", &value);  
    
arr[pos2 - 1] = value;      
printf("Array after update:\n");      
for(i = 0; i < n; i++) {         
printf("%d ", arr[i]);    
}          
printf("\n\nUse of DELETE operation.\n");     	
int pos3=pos;     
printf("Enter position to delete: ");     
scanf("%d", &pos3);      

for(i = pos3 - 1; i < n - 1; i++) {         
arr[i] = arr[i + 1];     
}     
n--;      
printf("Array after deletion:\n");     
for(i = 0; i < n; i++) {         
printf("%d ", arr[i]);    
}     
printf("\n\nUse of DISPLAY operation.\n");     
// it displays all array elements  
        
printf("display array elements: \n");     
for(i = 0; i < n; i++) {         
printf("%d ", arr[i]);     
}          
int key,found=0;          
printf("\n\nUse of SEARCH operation.\n");      
//it finds an element in the array and shows its position.      

printf("Enter element to search: "); 
scanf("%d", &key);      
for(i = 0; i < n; i++) {         
if(arr[i] == key) {             
printf("Element found at position %d\n", i + 1);             
found = 1;         
}     
}      
if(found == 0) {         
printf("Element not found in array.\n");     
} 
}
