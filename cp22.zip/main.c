#include <stdio.h> 
#include <math.h>  
// function to check prime number 
int isPrime(int n) {     
int i;      
if(n <= 1)         
return 0;      
for(i = 2; i <= n / 2; i++) {         
if(n % i == 0)             
return 0;     
}     
return 1; 
}  
// function to check Armstrong number 
int isArmstrong(int n) {     
int original, remainder, result = 0, digits = 0;      
original = n;     
while(original != 0) {        
digits++;         
original /= 10;     
}          
original = n;     
while(original != 0) {         
remainder = original % 10;         
result = result + pow(remainder, digits);         
original /= 10;     
}     
return (result == n); 
}  
// function to check perfect number 
int isPerfect(int n) {     
int i, sum = 0;      
for(i = 1; i <= n / 2; i++) {        
if(n % i == 0)            
 sum = sum + i;     
}     
return (sum == n); 
}  

int main() {    
 	int num;      
printf("Enter a number: ");     
scanf("%d", &num);          
//for checking prime number     
//number is only divisible by 1 and the number itself      
if(isPrime(num))         
printf("%d is a Prime Number.\n", num);     
else         
printf("%d is not a Prime Number.\n", num);      
//for checking armstrong number     
//sum of its digits raised to the power of the total number of digits      
if(isArmstrong(num))         
printf("%d is an Armstrong Number.\n", num);     
else         
printf("%d is not an Armstrong Number.\n", num);      
//for checking Perfect number     
//sum of all its divisors must be equal to the number      
if(isPerfect(num))         
printf("%d is a Perfect Number.\n", num);     
else         
printf("%d is not a Perfect Number.\n", num);      
return 0; 
} 
