#include <stdio.h> 
#include <math.h>  
// function to calculate area of circle 
int area(int a) {     
return a*a; 
} 
// function to calculate circumference of circle 
float circumference(int a) {     
return 2*3.14*a; 
}  
int main() {     
int a,b;     
float c;      
printf("Enter side: ");     
scanf("%d", &a);      
//for calculating area of circle     
b = area(a);     
printf("%d\n", b);          
//for calculating circumference of circle     
c = circumference(a);     
printf("%.2f", c); 
}
