#include <stdio.h>  
// funtion for call by value 
void swapByValue(int x, int y) {     
int temp;      
temp = x;     
x = y;     
y = temp;      
printf("\nCall by Value:");     
printf("\nx = %d y = %d\n", x, y); 
} 
// function for call by reference 
void swapByReference(int *x, int *y) {     
int temp;      
temp = *x;     
*x = *y;     
*y = temp;      
printf("\nCall by Reference:");     
printf("\nx = %d y = %d\n", *x, *y); 
}  
int main() {     
int a, b;      
printf("Enter two numbers: ");     
scanf("%d %d", &a, &b);      
printf("\nBefore swapping:");     
printf("\na = %d b = %d\n", a, b);      
// Call by Value     
swapByValue(a, b);     
// Call by Reference     
swapByReference(&a, &b); 
} 
