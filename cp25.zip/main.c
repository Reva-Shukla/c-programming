#include <stdio.h> 
// function to show use of pointer as arguments 
void update(int *a, int *b) { 
*a = *a + 10; 
*b = *b + 20; 
} 
int main() { 
int x, y; 
printf("Enter two numbers: "); 
scanf("%d %d", &x, &y); 
// passing addresses as arguments 
update(&x, &y); 
printf("\nAfter function call:"); 
printf("\nx = %d y = %d\n", x, y); 
} 
