#include <stdio.h> 
#include <string.h>  
int main() {     
char str[100], sub[100];     
int i, j, count = 0;      
printf("Enter main string: ");     
scanf("%s", str);      
printf("Enter substring: ");     
scanf("%s", sub);      
// checking substring     
for(i = 0; str[i] != '\0'; i++) {         
for(j = 0; sub[j] != '\0'; j++) {             
if(str[i + j] != sub[j]) {                
 break;             
}         
}          
// if substring matched         
if(sub[j] == '\0') {             
count++;         
}     
}     
printf("Total occurrences = %d", count);  
}
