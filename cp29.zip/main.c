#include <stdio.h>  
struct Distance {     
int feet;     
int inch; 
};  
int main() {     
struct Distance d1, d2, sum;      
// first distance     
printf("Enter first distance\n");          
printf("Feet1  Inch1: ");     
scanf("%d %d", &d1.feet,&d1.inch);      
// second distance     
printf("\nEnter second distance\n");          
printf("Feet2  Inch2: ");     
scanf("%d %d", &d2.feet,&d2.inch);      
sum.feet = d1.feet + d2.feet;     
sum.inch = d1.inch + d2.inch;      
if(sum.inch >= 12) {         
sum.feet++;         
sum.inch = sum.inch - 12;     
}      
printf("\nTotal Distance = %d feet %d inch",sum.feet, sum.inch);  
}
