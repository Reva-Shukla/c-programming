#include <stdio.h>  
struct Employee {     
int id;     
//array within structures     
char name[50];     
float salary; 
};  
int main() {          
struct Employee emp[5];     
int i;      
//array of structures     
for(i = 0; i < 5; i++) {         
printf("Enter details of Employee %d\n", i + 1);          
printf("Enter ID: ");         
scanf("%d", &emp[i].id);          
printf("Enter Name: ");         
scanf("%s", emp[i].name);          
printf("Enter Salary: ");         
scanf("%f", &emp[i].salary);         
printf("\n");     
}      
printf("\nEmployee Information\n");          
for(i = 0; i < 5; i++) {         
printf("\nEmployee %d\n", i + 1);         
printf("ID = %d\n", emp[i].id);         
printf("Name = %s\n", emp[i].name);         
printf("Salary = %.2f\n", emp[i].salary);     
}  
}  
