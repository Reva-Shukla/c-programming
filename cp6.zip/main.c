/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int a,b;
   float add, subtract, multiply, division;
   printf("enter a = ");
   scanf("%d",&a);
   printf("enter b = ");
   scanf("%d",&b);
   
   add=a+b;
   printf("sum of a and b is %.2f",add);
   
   subtract=a-b;
   printf("\nsubtraction of a and b is %.2f",subtract);
   
   multiply=a*b;
   printf("\nmultiplication of a and b is %.2f",multiply);
   
   division=a/b;
   printf("\ndivision of a and b is %.2f",division); 
}
