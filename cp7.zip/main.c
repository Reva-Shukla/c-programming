#include<stdio.h>
#include<math.h>
int main() 
{     
    int V, u, a, t;
    printf("(A) V = u + at\n");
    printf("enter u, a, t: ");
    scanf("%d %d %d",&u,&a,&t);
    
    V=u+(a*t);      
    printf("The solution is : ");
    printf("%d",V);
    
    float S;
    int u1, t1, a1;
    printf("\n\n(B) S = ut+1/2at2 \n");
    printf("enter u, a, t: ");
    scanf("%d %d %d",&u1,&a1,&t1);
    
    S=((u1*t1)+((a1*t1*t1)/2));
    printf("The solution is: ");
    printf("%.2f",S);
    
    int T,a2,b2,c2;
    printf("\n\n(C)T=2*a+√b+9c \n");
    printf("enter a, b, c: ");
    scanf("%d %d %d",&a2,&b2,&c2);
    
    T=2*a2+sqrt(b2)+9*c2;
    printf("The solution is: ");
    printf("%d",T);
    
    float H;
    int b3,p3;
    printf("\n\n(D)H=√b2+p2  \n");
    printf("enter b, p: ");
    scanf("%d %d",&b3,&p3);
    
    H=sqrt(((b3*b3)+(p3*p3)));
    printf("The solution is: "); 
    printf("%.2f",H);  
} 