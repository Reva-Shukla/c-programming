/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,c,max;
    printf("using Conditional operators\n");
    printf("enter A ,B ,C: ");
    scanf("%d %d %d",&a,&b,&c);
    max = (a > b) ? (a > c ? a : c) : (b > c ? b : c);
    printf("greatest of 3 numbers: %d\n\n",max);
    int a1,b1,c1,max1;
    printf("using If-Else operators\n");
    printf("enter A ,B ,C: ");
    scanf("%d %d %d",&a1,&b1,&c1);
    if(a1>b1)
    {
        if (a1>c1){
             max1=a1;
            }         
        else{
            max1=c1;
            }
     }
    else if(b1>c1){
        max1=b1;
         }
    else{
        max1=c1;
        } 
        printf("greatest of 3 numbers: %d",max1); 
}
