#include<stdio.h>
int main() 
{
    char alphabet;
    printf("enter the alphabet=");
    scanf("%c",&alphabet);
    switch (alphabet)
    {
        case 'a':case 'e':case 'i':case 'o':case 'u':
        printf("vowel");
        break;
        
        default:
        printf("consonant");
        break;
    }     
    int n;
    printf("\n\nenter number:");
    scanf("%d",&n);
    switch(n>0)
    {
        case 1 :
        printf("Positive number ");
        break;
        
        case 0:
        switch(n<0)
        {
            case 1:
            printf("Negative number ");
            break;
            
            case 0:
            printf("Zero");
        }
        break;
    }
}