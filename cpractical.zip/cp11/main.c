#include<stdio.h> 
int main() 
{ 
int i=1,N,sum=0; 
printf("enter N:"); 
scanf("%d",&N); 

i!=0; 
while(i<=N) 
{         
sum=sum+i;
 i=i+1; 
}
printf("sum=%d",sum); 
} 
