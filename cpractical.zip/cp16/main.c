#include <stdio.h> 
int main() 
{ 
int i; 
for(i = 1; i <= 36; i++) { 
printf("%2d ", i); 
if(i % 6 == 0) { 
printf("\n"); 
} 
} 
} 
