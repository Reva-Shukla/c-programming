#include <stdio.h> 
#include <string.h> 

int main() {     
char str1[100], str2[100];          
printf("use of STRLEN function\n");     
//it finds length of the string          
printf("Enter a string: ");     
scanf("%s", str1);     
printf("Length of string = %d\n", strlen(str1));               
printf("\nuse of STRCAT function\n");     
//it joins two strings          
printf("Enter first string: ");     
scanf("%s", str1);      
printf("Enter second string: ");     
scanf("%s", str2);      
strcat(str1, str2);     
printf("Concatenated string = %s\n", str1);               
printf("\nuse of STRCPY function\n");     
//it copies one string to another          
printf("Enter source string: ");     
scanf("%s", str1);      
strcpy(str2, str1);     
printf("Copied string = %s\n", str2);               
printf("\nuse of STRCMP function\n");     
//it compares two strings          
printf("Enter first string: ");     
scanf("%s", str1); 
printf("Enter second string: ");     
scanf("%s", str2);      
int result;     
result = strcmp(str1, str2);      
if(result == 0)         
printf("Strings are equal.\n");     
else         
printf("Strings are not equal.\n");           

printf("\nuse of STRREV function\n");     
//it reverses a string          
printf("Enter a string: ");     
scanf("%s", str1);      
strrev(str1);     
printf("Reversed string = %s\n", str1); 
} 
