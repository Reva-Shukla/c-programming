#include <stdio.h>

int main()
{
    char name[50]; 
    scanf("%s",&name); 
    printf("%s is in G14",name);
}