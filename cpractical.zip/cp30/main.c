#include <stdio.h>  
struct Complex {     
int real;     
int imag; 
};  
int main() {      
struct Complex c1, c2, sum;      
// first complex number     
printf("Enter first complex number\n");      
printf("RealPart : ");     
scanf("%d", &c1.real);      
printf("Imaginary part: ");     
scanf("%d", &c1.imag);      
// second complex number     
printf("\nEnter second complex number\n");      
printf("Real part: ");     
scanf("%d", &c2.real);      
printf("Imaginary part: ");     
scanf("%d", &c2.imag);      
sum.real = c1.real + c2.real;     
sum.imag = c1.imag + c2.imag;      
printf("\nSum = %d + %di",            
sum.real, sum.imag);  
}  
