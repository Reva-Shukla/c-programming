//input.txt file 
//banana  
#include <stdio.h> 
#include <string.h>  
int main() {      
FILE *fp;      
char str[100],word[20],replace[20];     
int count = 0;      
// open file     
fp = fopen("input.txt", "r");      
if(fp == NULL) {         
printf("File not found");         
return 0;     
}      
// read file      
fgets(str, sizeof(str), fp);      
printf("Enter word to find: ");     
scanf("%s", word);      
printf("Enter replacement word: ");     
scanf("%s", replace);      
char *p;     
p = strstr(str, word);      
while(p != NULL) {         
count++;          
strncpy(p, replace, strlen(replace));         
p = strstr(p + 1, word);     
}     
fclose(fp);      
printf("\nNew String = %s", str); 
printf("\nTotal occurrences = %d", count); 
} 
