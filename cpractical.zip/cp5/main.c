/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int r;
    float area, circumference;
    printf("enter radius of circle:");
    scanf("%d",&r); area=3.14*r*r;
    
    printf("area of circle = %.2f",area);
    circumference=2*3.14*r;
    
    printf("\ncircumference of circle = %.2f",circumference);
}
