/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,temp;
    printf("enter A, B:\n");
    scanf("%d %d",&a,&b);
    temp=a;     
    a=b;     
    b=temp;
    printf("swapped values using temporary variables");
    printf("\n%d %d\n\n",a,b);
    int c,d;
    printf("enter C, D:\n");
    scanf("%d %d",&c,&d);
    c=c+d;
    d=c-d;
    c=c-d;
    printf("swapped values without using temporary variable");
    printf("\n%d %d",c,d); 
}
